
- update changelog
- update readme
- update lib.rs
- update cargo.toml
  - bump version number on the root Cargo.toml and examples
