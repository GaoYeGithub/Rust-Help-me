# shadow

This animated example demonstrates shadow mapping.

## To Run

```
cargo run --example shadow
```

## Screenshots

![Shadow mapping](./screenshot.png)
