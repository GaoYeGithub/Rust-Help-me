# mipmap

This example shows how to generate and make use of mipmaps.

## To Run

```
cargo run --example mipmap
```

## Screenshots

![Mip maps](./screenshot.png)
