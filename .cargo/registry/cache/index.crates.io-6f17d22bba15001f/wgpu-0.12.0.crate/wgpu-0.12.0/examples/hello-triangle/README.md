# hello-triangle

This example renders a triangle to a window.

## To Run

```
cargo run --example hello-triangle
```

## Screenshots

![Triangle window](./screenshot.png)
