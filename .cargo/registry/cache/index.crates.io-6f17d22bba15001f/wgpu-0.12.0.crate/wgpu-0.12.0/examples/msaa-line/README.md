# msaa-line

This example shows how to render lines using MSAA.

## To Run

```
cargo run --example msaa-line
```

## Screenshots

![MSAA line](./screenshot.png)
