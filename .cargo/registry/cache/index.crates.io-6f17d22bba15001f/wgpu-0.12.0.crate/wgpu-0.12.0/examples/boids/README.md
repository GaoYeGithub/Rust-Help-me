# boids

Flocking boids example with gpu compute update pass

## To Run

```
cargo run --example boids
```

## Screenshots

![Boids example](./screenshot.png)
