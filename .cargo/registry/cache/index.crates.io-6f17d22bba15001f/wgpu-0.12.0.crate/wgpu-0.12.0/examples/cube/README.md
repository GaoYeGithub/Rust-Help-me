# cube

This example renders a textured cube.

## To Run

```
cargo run --example cube
```

## Screenshots

![Cube example](./screenshot.png)
