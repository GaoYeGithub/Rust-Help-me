# hello-windows

This example renders a set of 16 windows, with a differently colored background

## To Run

```
cargo run --example hello-windows
```

## Screenshots

![16 windows](./screenshot.png)
