/// The hasher used to compare layouts.
pub type Hasher = twox_hash::XxHash;
