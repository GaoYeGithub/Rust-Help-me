//! Listen to window events.

mod event;

pub use event::Event;
