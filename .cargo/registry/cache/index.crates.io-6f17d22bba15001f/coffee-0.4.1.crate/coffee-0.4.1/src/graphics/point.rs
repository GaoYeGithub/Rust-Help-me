use nalgebra;

/// A 2D point.
pub type Point = nalgebra::Point2<f32>;
