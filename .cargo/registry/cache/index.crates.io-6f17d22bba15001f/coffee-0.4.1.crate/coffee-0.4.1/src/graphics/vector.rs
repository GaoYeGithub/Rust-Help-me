use nalgebra;

/// A 2D vector.
pub type Vector = nalgebra::Vector2<f32>;
