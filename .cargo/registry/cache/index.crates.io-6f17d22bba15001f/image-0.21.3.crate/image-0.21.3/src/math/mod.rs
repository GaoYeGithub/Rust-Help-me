//! Mathematical helper functions and types.
pub mod nq;
pub mod utils;
