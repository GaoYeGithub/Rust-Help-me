#!/usr/bin/env python

print ("check.py temporarily removed due to DMCA claim...it used tabs instead of spaces so nothing good is lost")
