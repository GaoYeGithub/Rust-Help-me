# image-tiff
[![Build Status](https://travis-ci.org/PistonDevelopers/image-tiff.svg?branch=master)](https://travis-ci.org/PistonDevelopers/image-tiff)

TIFF decoding and encoding library in pure Rust
