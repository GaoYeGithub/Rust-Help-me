# Andrew

This crate provides convenient drawing of objects such as shapes, lines and text to buffers
