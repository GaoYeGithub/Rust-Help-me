/// A module that contains functions and objects relating to rectangles
pub mod rectangle;
