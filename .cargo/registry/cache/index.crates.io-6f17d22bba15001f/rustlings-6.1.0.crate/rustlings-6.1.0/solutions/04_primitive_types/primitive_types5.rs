fn main() {
    let cat = ("Furry McFurson", 3.5);

    // Destructuring the tuple.
    let (name, age) = cat;

    println!("{name} is {age} years old");
}
