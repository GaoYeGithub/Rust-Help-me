fn main() {
    // Congratulations, you finished the first exercise 🎉
    // As an introduction to Rustlings, the first exercise only required
    // entering `n` in the terminal to go to the next exercise.
}
