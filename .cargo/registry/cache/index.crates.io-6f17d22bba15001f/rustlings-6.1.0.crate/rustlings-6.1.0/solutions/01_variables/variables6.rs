// The type of constants must always be annotated.
const NUMBER: u64 = 3;

fn main() {
    println!("Number: {NUMBER}");
}
