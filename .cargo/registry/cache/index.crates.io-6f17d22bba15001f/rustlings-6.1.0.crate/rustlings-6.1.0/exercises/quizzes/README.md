# Quizzes

After every couple of sections, there will be a quiz in this directory that'll test your knowledge on a bunch of sections at once.
