fn main() {
    // TODO: Change the line below to fix the compiler error.
    let x: i32;

    println!("Number {x}");
}
