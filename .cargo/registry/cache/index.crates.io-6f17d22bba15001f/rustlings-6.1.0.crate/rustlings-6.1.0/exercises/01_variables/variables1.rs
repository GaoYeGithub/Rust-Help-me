fn main() {
    // TODO: Add missing keyword.
    x = 5;

    println!("x has the value {x}");
}
