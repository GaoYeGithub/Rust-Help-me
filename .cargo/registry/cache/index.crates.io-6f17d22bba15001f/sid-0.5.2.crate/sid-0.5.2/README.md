# sid
Tiny rust crate providing strongly typed id types and an id-based vector.
