#![cfg(target_os = "android")]

pub use crate::api::android::*;
pub use winit::event_loop::EventLoop;
