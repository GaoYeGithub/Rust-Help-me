use bevy::prelude::*;

fn main() {
    App::new().run();
}
